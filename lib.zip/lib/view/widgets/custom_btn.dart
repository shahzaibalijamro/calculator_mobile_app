import 'package:flutter/material.dart';

Widget customBtn({
  bool isStadium = false,
  required String btnVar,
  Color btnColor = Colors.orange,
  Color txtColor = Colors.white,
  required VoidCallback onTapFunction,
}) {
  return InkWell(
    onTap: () {
      onTapFunction();
    },
    child: Container(
      width: isStadium ? 156 : 62,
      height: isStadium ? 50 : 62,
      decoration: BoxDecoration(
        color: btnColor,
        borderRadius: const BorderRadius.all(Radius.circular(50)),
      ),
      child: Center(
        child: Text(btnVar, style: TextStyle(color: txtColor, fontSize: 20)),
      ),
    ),
  );
}
