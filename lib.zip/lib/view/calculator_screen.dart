import 'widgets/custom_btn.dart';

import 'package:flutter/material.dart';

class CalculatorScreen extends StatelessWidget {
  const CalculatorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.black,

        title: Text(
          "Calculator".toUpperCase(),
          style: const TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            Container(
              color: Colors.black,
              height: 250,
              width: double.infinity,
              alignment: Alignment.bottomRight,
              child: const Padding(
                padding: EdgeInsets.only(right: 20),
                child: Text(
                  "0sdgsdgsdsdgsgsdgsdgsdgsdgsdgsdggsdgsd",
                  maxLines: 1,
                  style: TextStyle(color: Colors.white, fontSize: 46),
                ),
              ),
            ),
            SizedBox(height: 16),
            Container(
              child: Column(
                spacing: double.minPositive,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      customBtn(
                        btnVar: "AC",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "+/-",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "%",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(btnVar: "÷", onTapFunction: () {}),
                    ],
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                    children: [
                      customBtn(
                        btnVar: "7",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "8",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "9",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(btnVar: "X", onTapFunction: () {}),
                    ],
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                    children: [
                      customBtn(
                        btnVar: "4",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "5",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "6",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(btnVar: "-", onTapFunction: () {}),
                    ],
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                    children: [
                      customBtn(
                        btnVar: "1",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "2",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: "3",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(btnVar: "+", onTapFunction: () {}),
                    ],
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                    children: [
                      customBtn(
                        isStadium: true,
                        btnVar: "0",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(
                        btnVar: ".",
                        onTapFunction: () {},
                        btnColor: Colors.grey,
                      ),
                      customBtn(btnVar: "=", onTapFunction: () {}),
                    ],
                  ),
                  // SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
